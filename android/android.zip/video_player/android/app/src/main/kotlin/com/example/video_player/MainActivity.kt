package com.example.video_player

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
